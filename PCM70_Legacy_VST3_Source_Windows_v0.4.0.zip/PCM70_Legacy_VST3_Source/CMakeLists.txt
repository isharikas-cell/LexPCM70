cmake_minimum_required(VERSION 3.22)
project(PCM70Legacy VERSION 0.4.0)

include(FetchContent)
FetchContent_Declare(
    JUCE
    GIT_REPOSITORY https://github.com/juce-framework/JUCE.git
    GIT_TAG 8.0.6
    GIT_SHALLOW TRUE
)
FetchContent_MakeAvailable(JUCE)

juce_add_plugin(PCM70Legacy
    COMPANY_NAME "Independent Audio Lab"
    BUNDLE_ID "audio.independent.pcm70legacy"
    PLUGIN_MANUFACTURER_CODE InAu
    PLUGIN_CODE Pm70
    FORMATS VST3
    PRODUCT_NAME "PCM70 Legacy"
    DESCRIPTION "Vintage-inspired stereo reverb"
    IS_SYNTH FALSE
    NEEDS_MIDI_INPUT FALSE
    NEEDS_MIDI_OUTPUT FALSE
    IS_MIDI_EFFECT FALSE
    EDITOR_WANTS_KEYBOARD_FOCUS FALSE
    COPY_PLUGIN_AFTER_BUILD FALSE
)

juce_generate_juce_header(PCM70Legacy)
target_sources(PCM70Legacy PRIVATE
    Source/PluginProcessor.cpp
    Source/PluginProcessor.h
    Source/PluginEditor.cpp
    Source/PluginEditor.h
)
target_compile_features(PCM70Legacy PRIVATE cxx_std_17)
target_compile_definitions(PCM70Legacy PUBLIC
    JUCE_WEB_BROWSER=0
    JUCE_USE_CURL=0
    JUCE_VST3_CAN_REPLACE_VST2=0
)
target_link_libraries(PCM70Legacy PRIVATE
    juce::juce_audio_utils
    juce::juce_dsp
    PUBLIC juce::juce_recommended_config_flags
           juce::juce_recommended_lto_flags
           juce::juce_recommended_warning_flags
)
